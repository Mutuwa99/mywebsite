var parallax = function() {
    'use strict';

    $('.parallax').parallax("50%", 0, 0.1, true);
    $('.parallax-two').parallax("50%", 0, 0.1, true);
    $('.parallax-three').parallax("50%", 0, 0.1, true);
    $('.parallax-four').parallax("50%", 0, 0.1, true);
}();